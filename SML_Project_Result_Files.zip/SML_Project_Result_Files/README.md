# SML Project – Result Files

This folder contains the saved evaluation results and figures for the two-dataset, four-model Statistical Machine Learning project.

## Tables (CSV)
- `final_two_dataset_eight_model_comparison.csv`: all eight model–dataset experiments and evaluation metrics.
- `final_dataset_wise_metric_leaders.csv`: leading model for each metric within each dataset.
- `assistments_2009_2010_model_comparison.csv`: Dataset 1 model results extracted from the combined comparison.
- `assistments_2015_model_comparison.csv`: Dataset 2 model comparison.
- `assistments_2015_bkt_mastery_summary.csv`: BKT final mastery estimates by student and sequence for Dataset 2.
- `assistments_2015_test_predictions.csv`: Dataset 2 held-out test predictions.

## Graphs (PNG)
- Accuracy comparison
- F1-score comparison
- ROC-AUC comparison
- Project methodology flowchart

## Notes
- Dataset 2 uses `sequence_id` as a proxy grouping variable because the supplied CSV does not include a separate skill identifier.
- Dataset 2 partial-credit observations were excluded from the binary-response experiment.
- The two datasets have different schemas and feature availability; cross-dataset comparisons should be interpreted with the limitations described in the project report.
