# ASSISTments 2009–2010 — Dataset 1 Results

This folder contains the saved evaluation results for the four Dataset 1 models.

## Files
- `Tables/assistments_2009_2010_model_comparison.csv`: actual held-out test metrics for BKT, Logistic Regression, Decision Tree and Random Forest.
- `ASSISTments_Dataset1_Four_Models_Improved.ipynb`: executed Dataset 1 notebook with code and outputs.
- `Graphs/`: project comparison visualizations and methodology flowchart.

## Results
The BKT model achieved the highest accuracy (70.18%) and F1-score (80.23%).
Random Forest achieved the highest ROC-AUC (0.722) among the four models.

## Metrics
Accuracy, precision, recall, F1-score and ROC-AUC are higher-is-better.
Brier score and log loss are lower-is-better.

Note: The CSV contains the metric values displayed in the executed Dataset 1 notebook. The notebook also contains code to export the detailed BKT mastery report and test predictions when its final export cell is run in the same execution environment.
